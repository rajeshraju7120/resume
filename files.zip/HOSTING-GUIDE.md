# How to Host Your Portfolio on GitHub Pages

## Step-by-Step Guide

### Prerequisites
- A GitHub account (create one free at github.com if you don't have one)
- Your portfolio HTML file (rajesh-portfolio.html)

---

## Option 1: Quick Method (No Git Installation Needed)

### Step 1: Create GitHub Account
1. Go to https://github.com
2. Click "Sign up"
3. Choose username (e.g., "rajesh-r" or "rajeshraju7120")
4. Complete registration

### Step 2: Create a New Repository
1. Click the "+" icon (top right) → "New repository"
2. Name it: `your-username.github.io` 
   - Example: `rajesh-r.github.io` or `rajeshraju7120.github.io`
   - ⚠️ **Important**: Use YOUR actual username instead of "your-username"
3. Select "Public"
4. Check "Add a README file"
5. Click "Create repository"

### Step 3: Upload Your Portfolio
1. In your new repository, click "Add file" → "Upload files"
2. Rename `rajesh-portfolio.html` to `index.html` (this is important!)
3. Drag and drop the `index.html` file
4. Scroll down and click "Commit changes"

### Step 4: Enable GitHub Pages
1. In your repository, click "Settings" (top menu)
2. Scroll down and click "Pages" (left sidebar)
3. Under "Source", select "main" branch
4. Click "Save"
5. Wait 2-3 minutes

### Step 5: Visit Your Live Website! 🎉
Your portfolio will be live at:
```
https://your-username.github.io
```
Example: `https://rajesh-r.github.io`

---

## Option 2: Using Git (For More Control)

### Prerequisites
- Install Git from https://git-scm.com/downloads
- Install GitHub Desktop (optional, easier): https://desktop.github.com

### Steps:
```bash
# 1. Create repository on GitHub (same as Option 1, Step 2)

# 2. Clone the repository
git clone https://github.com/your-username/your-username.github.io.git
cd your-username.github.io

# 3. Copy your portfolio file and rename it
# Rename rajesh-portfolio.html to index.html
# Copy index.html to the repository folder

# 4. Commit and push
git add .
git commit -m "Initial portfolio upload"
git push origin main

# 5. Your site will be live at: https://your-username.github.io
```

---

## After Hosting: Submit to Search Engines

### 1. Google Search Console
1. Go to https://search.google.com/search-console
2. Click "Start now"
3. Enter your URL: `https://your-username.github.io`
4. Verify ownership (easiest: HTML file upload method)
5. Submit your URL for indexing

### 2. Bing Webmaster Tools
1. Go to https://www.bing.com/webmasters
2. Add your site
3. Verify and submit sitemap

---

## Tips for Better Search Results

### 1. Update Your Resume Download Link
In your `index.html`, find this line:
```html
<a href="#" class="download-btn" onclick="alert('Add your resume PDF link here or create a download functionality'); return false;">📄 Download Resume</a>
```

Upload your PDF resume to GitHub and change it to:
```html
<a href="RajeshR_Resume.pdf" class="download-btn" download>📄 Download Resume</a>
```

### 2. Share Your Portfolio Link
- Add it to your LinkedIn profile
- Add it to your email signature
- Share on social media
- Add it to your resume

### 3. Add a Custom Domain (Optional)
If you want a custom domain like `rajesh-r.com`:
1. Buy domain from Namecheap/GoDaddy (~$10-15/year)
2. In GitHub repository settings → Pages
3. Add custom domain
4. Follow GitHub's DNS setup instructions

---

## Troubleshooting

### Site not loading?
- Wait 5-10 minutes after first upload
- Make sure file is named `index.html` (not `rajesh-portfolio.html`)
- Check repository name is `your-username.github.io`

### Want to update your portfolio?
1. Edit `index.html` on GitHub directly (click pencil icon)
2. Or re-upload the file
3. Changes appear in 1-2 minutes

### 404 Error?
- Ensure repository is public
- Ensure file is named `index.html`
- Check Pages settings are enabled

---

## Alternative Hosting Options

### Netlify (Also Free)
1. Go to https://netlify.com
2. Drag and drop your HTML file
3. Get instant URL like `your-site.netlify.app`
4. Can add custom domain

### Vercel (Also Free)
1. Go to https://vercel.com
2. Import from GitHub or upload files
3. Get URL like `your-site.vercel.app`

---

## Expected Timeline

- **Hosting setup**: 10-15 minutes
- **Site goes live**: 2-5 minutes after upload
- **Google indexes your site**: 1-2 weeks (faster if submitted to Search Console)
- **Appears in search results**: 2-4 weeks

---

## Need Help?

If you face any issues:
1. Check GitHub Pages documentation: https://pages.github.com
2. GitHub support: https://support.github.com
3. Or feel free to ask me for help!

---

## Summary Checklist

- [ ] Create GitHub account
- [ ] Create repository named `your-username.github.io`
- [ ] Rename portfolio file to `index.html`
- [ ] Upload to repository
- [ ] Enable GitHub Pages in settings
- [ ] Wait 5 minutes
- [ ] Visit `https://your-username.github.io`
- [ ] Submit to Google Search Console
- [ ] Share your portfolio link!

**Your portfolio will be live at: `https://your-username.github.io`**

Good luck! 🚀
